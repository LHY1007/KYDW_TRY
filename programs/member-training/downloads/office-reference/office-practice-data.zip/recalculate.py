from pathlib import Path
import numpy as np
from PIL import Image
for path in sorted(Path("masks").glob("*.png")):
    trimap = np.array(Image.open(path))
    true = trimap == 1
    valid = trimap != 3
    for shift in (5, 15):
        pred = np.zeros_like(true)
        pred[:, shift:] = true[:, :-shift]
        g, p = true & valid, pred & valid
        inter = (g & p).sum()
        print(path.stem, shift, 2*inter/(g.sum()+p.sum()), inter/(g|p).sum())
